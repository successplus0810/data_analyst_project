import subprocess

subprocess.run("C:\Program Files\Python39\python.exe -m pip install -r requirements.txt")

